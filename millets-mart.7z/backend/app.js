const express = require('express');
const bodyParser = require('body-parser');
const app = express();

app.use(bodyParser.json());

app.use((req,res,next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Headers',
    'Origin, X-Requested-With, Content-Type, Accept'
);
    next();
});

app.get('/api/posts',(req,res,next) => {
    const posts = [
        {
            id: '1',
            title: 'Areka',
            content: 'This is coming from server'
        },
        {
            id: 2,
            title: 'Millets',
            content: 'This is coming from server'
        },
        {
            id:3,
            title: 'Coconut',
            content: 'this is coming from server'
        }
    ]
    res.status(200).json({
        message:'Posts fetch success',
        posts:posts
    });
});
    app.get('/api/products',(req,res,next) => {
        const products = [
            {
                id: '1',
                title: 'Areka',
                content: 'This is coming from server'
            },
            {
                id: 2,
                title: 'Millets',
                content: 'This is coming from server'
            },
            {
                id:3,
                title: 'Coconut',
                content: 'this is coming from server'
            },
            {
                id:4,
                title: 'Tendur-Coconut',
                content: 'this is coming from server'
            },
            {
                id:5,
                title: 'Coconut-oil',
                content: 'This is coming from server'
            }
        ]
        res.status(200).json({
            message:'products fetch success',
            products: products
        });
});    
    app.post('/api/productdetail',(req,res,next) => {
          console.log(req.body);
          res.status(201).json({
              message: "product details",
              productDetials: {
                id:3,
                title: 'Coconut',
                content: 'this is coming from server'
            }
          });
    });
module.exports = app;
