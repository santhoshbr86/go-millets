import { Injectable } from '@angular/core';
import { HomeModule } from '../home/home.module';
import { HttpClient } from '@angular/common/http';
import { Subject } from 'rxjs';
import {map} from 'rxjs/operators';
@Injectable()
export class PostsService {
  subject = new Subject<Post[]>();
  constructor(private http: HttpClient) { }
  getPosts() {
    return this.http.get<{message: string, posts: Post[]}>('http://localhost:3000/api/posts').pipe(
      map((data) => {
        return data;
      })
    );
  }
}

export interface Post {
  id: string;
  title: string;
  content: string;
}
