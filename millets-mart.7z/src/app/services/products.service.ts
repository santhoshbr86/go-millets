import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Subject } from 'rxjs';
@Injectable()
export class ProductsService {
  private subject = new Subject();
  products: Product[] = [];
  constructor(private http: HttpClient) { }
  getProducts () {
    return this.http.get<{message: string, products: Product[]}>('/assets/resources/products.json').pipe(
      map((data) => {
        return data;
      })
    );
  }
  // getProductDetials(id) {
  //   return this.http.post('http://localhost:3000/api/productdetail', {id: id}).pipe(
  //     map((data) => {
  //         return data;
  //     })
  //   );
  // }

}

export interface Product {
  id: string;
  title: string;
  content: string;
  cat: string;
  type: string;
}
