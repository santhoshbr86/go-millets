import { Component, OnInit, ViewChild, ChangeDetectorRef, ChangeDetectionStrategy } from '@angular/core';
import { ProductsService, Product } from '../services/products.service';
import {ProductDetailsComponent } from './product-details/product-details.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Store } from '@ngrx/store';
// import { ProductState, ProductsSelector } from '../store/products';
import * as fromstore from '../store';
import { Observable, Subscription } from 'rxjs';
export interface Product {
  id: number;
  title: string;
  content: string;
  cat: string;
  type: string;
}

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./products.component.scss']
})
export class ProductsComponent implements OnInit {
  productsList: Product[] = [];
  products: Product[] = [];
  @ViewChild(ProductDetailsComponent) private productdetail: ProductDetailsComponent;
  private co$: Observable<any>;
  private co_: Subscription;
  constructor(private productService: ProductsService,
    private modalService: NgbModal,
    private ref: ChangeDetectorRef,
    private pStore: Store<fromstore.StoreState>
   ) {
    this.co$ = pStore.select(fromstore.getAllProducts);

   }

  ngOnInit() {
    this.co$.subscribe(data => {
      console.log(data);
    });
    this.productService.getProducts().subscribe(data => {
      this.productsList = data.products;
      this.products = this.productsList;
      this.ref.markForCheck();
    });
  }
  openModal(pro) {
    // this.productdetail.getProduct(id);
    const modalRef = this.modalService.open(ProductDetailsComponent, {size: 'lg'});
    modalRef.componentInstance.product = pro;
  }
  updateProducts(data) {
   if (data.length > 0) {
    const temp = data.map( t => {
      return this.productsList.filter( p => {
        console.log(p);
      return p.cat.toLowerCase() === t.type.toLowerCase();
       });
    });
    this.products = temp.reduce((a, b) => a.concat(b), []);
  } else {
    this.products = this.productsList;
  }
    this.ref.markForCheck();
    console.log(this.products);
  }
}
