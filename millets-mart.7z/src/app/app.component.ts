import { Component } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { LoginComponent } from './login/login/login.component';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'AreEco';
  constructor(private modalService: NgbModal) {}
  openModal() {
    // this.productdetail.getProduct(id);
    const modalRef = this.modalService.open(LoginComponent, {size: 'lg'});
    // modalRef.componentInstance.id = id;
  }
}
