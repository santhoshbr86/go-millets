import { Component, OnInit } from '@angular/core';
import { NgbCarouselConfig } from '@ng-bootstrap/ng-bootstrap';
@Component({
  selector: 'app-banner',
  templateUrl: './banner.component.html',
  styleUrls: ['./banner.component.scss']
})
export class BannerComponent implements OnInit {
  // showNavigationArrows = false;
  images = [1, 2, 3].map(() => `https://picsum.photos/800/400?random&t=${Math.random()}`);
  constructor(private config: NgbCarouselConfig) {
    config.showNavigationArrows = false;
  }

  ngOnInit() {
  }

}
