import {
  ActionReducer,
  ActionReducerMap,
  createFeatureSelector,
  createSelector,
  MetaReducer
} from '@ngrx/store';
import { environment } from '../../environments/environment';
import * as fromProduct from './products';

export interface StoreState {
products: fromProduct.ProductState;
}

export const productReducers: ActionReducerMap<any> = {
products: fromProduct.reducer
};

export const getStoreState = createFeatureSelector<StoreState>('mainstore');

export const getProduct = createSelector(getStoreState, (state: StoreState) => state.products);
export const getAllProducts = createSelector(getProduct, fromProduct.getProducts);

export const metaReducers: MetaReducer<StoreState>[] = !environment.production ? [] : [];
