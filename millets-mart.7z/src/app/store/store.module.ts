import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StoreModule } from '@ngrx/store';
import { productReducers } from './reducer';
import { ProductsSelector } from './products/products.selector';
@NgModule({
  imports: [
    CommonModule,
    StoreModule.forRoot({}),
    StoreModule.forFeature('mainstore', productReducers)
  ],
  declarations: [],
  providers: []
})
export class AppStoreModule { }
