export interface Product {
    id: number;
    title: string;
    content: string;
    cat: string;
    type: string;
  }
